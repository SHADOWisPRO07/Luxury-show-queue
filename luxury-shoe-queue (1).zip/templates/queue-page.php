<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (is_user_logged_in()) {
    $current_user = wp_get_current_user();
    $email = $current_user->user_email;
} else {
    $email = '';
}
?>

<div id="luxury-shoe-queue">
    <h2>We Value Our Customers</h2>
    <p>We don't bulk manufacture shoes, emphasizing the exclusivity of our products. Please wait while we process your order.</p>
    <form id="queue-form">
        <label for="email">Enter your email to join the queue:</label>
        <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>
        <button type="submit">Join Queue</button>
    </form>
    <div id="otp-section" style="display: none;">
        <label for="otp">Enter OTP:</label>
        <input type="text" id="otp" name="otp" required>
        <button type="submit" id="verify-otp">Verify OTP</button>
    </div>
    <div id="queue-position-section" style="display: none;">
        <p>Your current position in the queue: <span id="queue-position"></span></p>
    </div>
</div>

<script>
    // JavaScript to handle queue position update and OTP verification
    jQuery(document).ready(function($) {
        var queuePosition;

        function showNotification(message) {
            if (Notification.permission === 'granted') {
                new Notification(message);
            } else if (Notification.permission !== 'denied') {
                Notification.requestPermission().then(function(permission) {
                    if (permission === 'granted') {
                        new Notification(message);
                    }
                });
            }
        }

        function updateQueuePosition() {
            if (queuePosition > 1) {
                queuePosition -= Math.floor(Math.random() * 2) + 1; // Decrease by 1 or 2
                $('#queue-position').text(queuePosition);
                showNotification('Your queue position is now ' + queuePosition);
                setTimeout(updateQueuePosition, 36000000); // Update every 10 hours
            } else {
                window.location.href = '/checkout'; // Redirect to checkout when position is 1
            }
        }

        $('#queue-form').on('submit', function(e) {
            e.preventDefault();
            var email = $('#email').val();
            $.post(ajaxurl, { action: 'send_otp', email: email }, function(response) {
                if (response.success) {
                    $('#otp-section').show();
                } else {
                    alert(response.data);
                }
            });
        });

        $('#verify-otp').on('click', function(e) {
            e.preventDefault();
            var otp = $('#otp').val();
            $.post(ajaxurl, { action: 'verify_otp', otp: otp }, function(response) {
                if (response.success) {
                    queuePosition = <?php echo luxury_shoe_queue_get_position(); ?>;
                    $('#queue-position').text(queuePosition);
                    $('#queue-position-section').show();
                    setTimeout(updateQueuePosition, 36000000); // Start updating after 10 hours
                } else {
                    alert(response.data);
                }
            });
        });
    });
</script>