<?php
namespace ReyCore\Customizer\Fields;

if ( ! defined( 'ABSPATH' ) ) exit;

class GroupEnd extends \Kirki_Control_Base {

	public $type = 'rey_group_end';
	public function render_content() {}

}
