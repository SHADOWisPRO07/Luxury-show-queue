<?php
namespace ReyCore\Customizer\Fields;

if ( ! defined( 'ABSPATH' ) ) exit;

class AccordionEnd extends \Kirki_Control_Base {

	public $type = 'rey_accordion_end';
	public function render_content() {}

}
