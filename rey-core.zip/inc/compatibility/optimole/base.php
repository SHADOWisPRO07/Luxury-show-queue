<?php
namespace ReyCore\Compatibility\Optimole;

if ( ! defined( 'ABSPATH' ) ) exit;

class Base extends \ReyCore\Compatibility\CompatibilityBase
{

	public function __construct()
	{

	}

}
