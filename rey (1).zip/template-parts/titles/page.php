<header class="rey-pageHeader">
	<?php the_title( '<h1 class="rey-pageTitle entry-title">', '</h1>' ); ?>
</header><!-- .rey-pageHeader -->
