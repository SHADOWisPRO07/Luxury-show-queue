<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div class="rey-overlay rey-overlay--site" style="opacity:0;"></div>
