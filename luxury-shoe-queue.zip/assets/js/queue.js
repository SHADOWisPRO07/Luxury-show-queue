jQuery(document).ready(function($) {
    var queuePosition;

    function showNotification(message) {
        if (Notification.permission === 'granted') {
            new Notification(message);
        } else if (Notification.permission !== 'denied') {
            Notification.requestPermission().then(function(permission) {
                if (permission === 'granted') {
                    new Notification(message);
                }
            });
        }
    }

    function updateQueuePosition() {
        if (queuePosition > 1) {
            queuePosition--;
            $('#queue-position').text(queuePosition);
            showNotification('Your queue position is now ' + queuePosition);
            setTimeout(updateQueuePosition, 36000000); // Update every 10 hours
        } else {
            window.location.href = '/checkout'; // Redirect to checkout when position is 1
        }
    }

    $('#queue-form').on('submit', function(e) {
        e.preventDefault();
        var email = $('#email').val();
        $.post(ajaxurl, { action: 'send_otp', email: email }, function(response) {
            if (response.success) {
                $('#otp-section').show();
            } else {
                alert(response.data);
            }
        });
    });

    $('#verify-otp').on('click', function(e) {
        e.preventDefault();
        var otp = $('#otp').val();
        $.post(ajaxurl, { action: 'verify_otp', otp: otp }, function(response) {
            if (response.success) {
                queuePosition = parseInt(response.data.queue_position);
                $('#queue-position').text(queuePosition);
                $('#queue-position-section').show();
                setTimeout(updateQueuePosition, 36000000); // Start updating after 10 hours
            } else {
                alert(response.data);
            }
        });
    });
});