<?php
/*
Plugin Name: Luxury Shoe Queue
Description: A simulated waiting system for a luxury custom shoe e-commerce site.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Include necessary files
include_once plugin_dir_path(__FILE__) . 'includes/queue-functions.php';
include_once plugin_dir_path(__FILE__) . 'includes/queue-admin.php';

// Enqueue scripts and styles
function luxury_shoe_queue_enqueue_scripts() {
    if (is_page('queue')) {
        wp_enqueue_script('luxury-shoe-queue-js', plugin_dir_url(__FILE__) . 'assets/js/queue.js', array('jquery'), '1.0', true);
        wp_localize_script('luxury-shoe-queue-js', 'ajaxurl', admin_url('admin-ajax.php'));
        wp_enqueue_style('luxury-shoe-queue-css', plugin_dir_url(__FILE__) . 'assets/css/queue.css', array(), '1.0');
    }
}
add_action('wp_enqueue_scripts', 'luxury_shoe_queue_enqueue_scripts');

// Activation and deactivation hooks
function luxury_shoe_queue_activate() {
    // Create queue page
    $queue_page = array(
        'post_title'    => 'Queue',
        'post_content'  => '[luxury_shoe_queue]',
        'post_status'   => 'publish',
        'post_type'     => 'page',
    );
    wp_insert_post($queue_page);
}
register_activation_hook(__FILE__, 'luxury_shoe_queue_activate');

function luxury_shoe_queue_deactivate() {
    // Deactivation code here
}
register_deactivation_hook(__FILE__, 'luxury_shoe_queue_deactivate');

// Change email sender
function luxury_shoe_queue_email_sender($original_email_address) {
    return 'store@dhaaram.com';
}
add_filter('wp_mail_from', 'luxury_shoe_queue_email_sender');

function luxury_shoe_queue_email_sender_name($original_email_from) {
    return 'Dhaaram Store';
}
add_filter('wp_mail_from_name', 'luxury_shoe_queue_email_sender_name');
?>