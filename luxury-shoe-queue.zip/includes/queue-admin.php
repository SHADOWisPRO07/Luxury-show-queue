<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Admin menu
function luxury_shoe_queue_admin_menu() {
    add_menu_page('Luxury Shoe Queue', 'Queue', 'manage_options', 'luxury-shoe-queue', 'luxury_shoe_queue_admin_page');
}
add_action('admin_menu', 'luxury_shoe_queue_admin_menu');

// Admin page
function luxury_shoe_queue_admin_page() {
    ?>
    <div class="wrap">
        <h1>Luxury Shoe Queue</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Queue Position</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $users = get_users();
                foreach ($users as $user) {
                    $position = get_user_meta($user->ID, 'luxury_shoe_queue_position', true);
                    if ($position) {
                        echo '<tr>';
                        echo '<td>' . $user->user_email . '</td>';
                        echo '<td>' . $position . '</td>';
                        echo '<td><a href="#" class="button">Change Position</a> <a href="#" class="button">Send Email</a></td>';
                        echo '</tr>';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}
?>