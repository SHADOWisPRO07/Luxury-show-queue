<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Redirect to queue page on checkout
function luxury_shoe_queue_redirect_to_queue() {
    if (is_checkout() && !is_wc_endpoint_url('order-received')) {
        wp_redirect(home_url('/queue'));
        exit;
    }
}
add_action('template_redirect', 'luxury_shoe_queue_redirect_to_queue');

// Shortcode for queue page
function luxury_shoe_queue_shortcode() {
    ob_start();
    include plugin_dir_path(__FILE__) . '../templates/queue-page.php';
    return ob_get_clean();
}
add_shortcode('luxury_shoe_queue', 'luxury_shoe_queue_shortcode');

// Send OTP to email
function luxury_shoe_queue_send_otp() {
    if (isset($_POST['email'])) {
        $email = sanitize_email($_POST['email']);
        $otp = rand(100000, 999999);
        // Save OTP in session
        $_SESSION['luxury_shoe_queue_otp'] = $otp;
        // Send OTP to email
        $subject = 'Your OTP Code';
        $message = '<p>Your OTP code is: <strong>' . $otp . '</strong></p>';
        $headers = array('Content-Type: text/html; charset=UTF-8');
        wp_mail($email, $subject, $message, $headers);
        wp_send_json_success('OTP sent to ' . $email);
    }
    wp_send_json_error('Invalid email');
}
add_action('wp_ajax_send_otp', 'luxury_shoe_queue_send_otp');
add_action('wp_ajax_nopriv_send_otp', 'luxury_shoe_queue_send_otp');

// Verify OTP
function luxury_shoe_queue_verify_otp() {
    if (isset($_POST['otp'])) {
        $otp = sanitize_text_field($_POST['otp']);
        if ($otp == $_SESSION['luxury_shoe_queue_otp']) {
            wp_send_json_success('OTP verified');
        }
        wp_send_json_error('Invalid OTP');
    }
    wp_send_json_error('OTP not provided');
}
add_action('wp_ajax_verify_otp', 'luxury_shoe_queue_verify_otp');
add_action('wp_ajax_nopriv_verify_otp', 'luxury_shoe_queue_verify_otp');

// Send position update email
function luxury_shoe_queue_send_position_update_email($email, $position) {
    $subject = 'Queue Position Update';
    $message = '<p>Your queue position is now: <strong>' . $position . '</strong></p>';
    $headers = array('Content-Type: text/html; charset=UTF-8');
    wp_mail($email, $subject, $message, $headers);
}

// Reset queue position on cart change
function luxury_shoe_queue_reset_position_on_cart_change() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        delete_user_meta($user_id, 'luxury_shoe_queue_position');
    } else {
        unset($_SESSION['luxury_shoe_queue_position']);
    }
}
add_action('woocommerce_cart_updated', 'luxury_shoe_queue_reset_position_on_cart_change');

// Get queue position
function luxury_shoe_queue_get_position() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $position = get_user_meta($user_id, 'luxury_shoe_queue_position', true);
        if (!$position) {
            $position = rand(6, 12);
            update_user_meta($user_id, 'luxury_shoe_queue_position', $position);
        }
    } else {
        if (!isset($_SESSION['luxury_shoe_queue_position'])) {
            $_SESSION['luxury_shoe_queue_position'] = rand(6, 12);
        }
        $position = $_SESSION['luxury_shoe_queue_position'];
    }
    return $position;
}
?>